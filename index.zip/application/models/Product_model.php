<?php 

class Product_model extends MY_Model
{
	
}