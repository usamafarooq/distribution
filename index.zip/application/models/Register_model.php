<?php 

class Register_model extends MY_Model
{
	
}