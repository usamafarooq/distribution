        <!-- /.Navbar  Static Side -->
            






            <div class="control-sidebar-bg"></div>
            <!-- Page Content -->
            <div id="page-wrapper">
                <!-- main content -->
                <div class="content">
                    <!-- Content Header (Page header) -->
                    <div class="content-header">
                        <div class="header-icon">
                            <i class="pe-7s-box1"></i>
                        </div>
                        <div class="header-title">
                            <h1>View Product</h1>
                            <small> </small>
                            <ol class="breadcrumb">
                                <li><a href="<?php echo base_url() ?>"><i class="pe-7s-home"></i> Home</a></li>

                                <li class="active">View Product</li>
                            </ol>
                        </div>
                    </div> <!-- /. Content Header (Page header) -->

                   <div class="row">
                        <div class="col-sm-12">
                            <div class="panel panel-bd">
                                <br>
                                <form method="post" action="">
                                    <input type="hidden" name="distribution_sort" value="<?php echo $distribution['dsr_code']; ?>">
                                    <div class="form-group row">
                                        <div class="col-md-6">
                                            <label class="col-md-3">Distribution Name</label>
                                            <div class="col-md-9">
                                                <input type="text" name="" class="form-control" value="<?php echo $distribution['scm_name'] ?>" readonly>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="col-md-3">Station</label>
                                            <div class="col-md-9">
                                                <input type="text" name="" class="form-control" value="<?php echo $distribution['dsr_code'] ?>" readonly>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <div class="col-md-6">
                                            <label class="col-md-3">Distribution Code</label>
                                            <div class="col-md-9">
                                                <input type="text" name="" class="form-control" value="<?php echo $distribution['station'] ?>" readonly>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="col-md-3">No of Batch</label>
                                            <div class="col-md-9">
                                                <select class="form-control" name="column">
                                                    <option>Select</option>
                                                    <option value="1">1</option>
                                                    <option value="2">2</option>
                                                    <option value="3">3</option>
                                                    <option value="4">4</option>
                                                    <option value="5">5</option>
                                                    <option value="6">6</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <button class="btn btn-info pull-right">Submit</button>
                                </form>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="panel panel-bd">
                                <div class="panel-heading">
                                    <div class="panel-title">
                                        <h4>View Product</h4>
                              
                                    </div>
                                </div>
        <form action="<?php echo base_url(); ?>orders/submit_data_order" method="post">
                                <div class="panel-body">
                                    
                                    <div class="table-responsive">

  
                                        <table id="dataTableExample2" class="table table-bordered table-striped table-hover">
                                            <thead>
                                                <tr>
                                                    <!-- <th>S.no</th>
                                                    <th>Distributor Code</th>
                                                    <th>Distributor Name</th> -->
                                                    <th>Products</th>
                                                    <!-- <th>SCM Product Code</th> -->
                                                    <th>IMS Pack Code</th>
<?php for ($i = 3; $i > 0; $i--){?>
<th><?php   echo $a =  date('M', strtotime("-".$i." month", strtotime(date('Y-m-01'))));  ?></th>

<?php } ?>
                                                    <th>Month Average Sale</th>
                                                    <th>Intransit</th>
                                                    <th>Closing</th>
                                                    <th>Closing Stock</th>
                                                    <th>Requirement</th>
                                                    <?php 
                                                        if (isset($column)) {
                                                            for ($i=0; $i < $column; $i++) { 
                                                                echo '<th>Order '.($i+1).'</th>';
                                                            }
                                                        }
                                                    ?>
                                                    <!-- <th>Order1</th>
                                                    <th>Order2</th>
                                                    <th>Order3</th> -->
                                                    <th>Order Quantity</th>
                                                    <th>Growth</th>
                                                    <th>Packs Carton</th>
                                                    <th>Priority</th>
                                                </tr>
                                            </thead>
                                            <tbody>                                          
                                            <?php 
                                            $con = 0;
                                            foreach($product_data_sort as $products_detail){ 
                                                $con++;




$sale = explode(",",$products_detail['sale']);
$month = explode(",",$products_detail['month']);

                                            ?>


                                           
                                                <tr>
                                                    <!-- <td><?php echo $con ?></td>
                                                    <td><?php echo $distribution['scm_code']; ?></td>
                                        <td><?php echo $distribution['scm_name']; ?></td> -->
                                        <td><?php echo $products_detail['product_name']; ?></td>
                                        <!-- <td><?php echo $products_detail['scm_product_code']; ?></td> -->
                                        <td><?php echo $products_detail['product_code']; ?></td>

<input type="hidden" name="distribution_code_order[]" value="<?php echo $distribution['dsr_code']; ?>">    
<input type="hidden" name="scm_product_order[]" value="<?php echo $products_detail['product_code']; ?>">     


<?php
$avg_sum = 0;
for ($i = -3; $i <= -1; $i++){
    $month_key = date('m', strtotime("$i month", strtotime(date('Y-m-01'))));
    $key = array_search($month_key, $month);
    if ($key <= -1) {
        $val = '0';

    }
    else{
        if (array_key_exists($key,$month)) {
            $val = $sale[$key];
            $avg_sum+= $val;
        }
        else{
            $val = '0';

        }
    }
    if ($i == -2) {
        $one = $val;
    }
    if ($i == -1) {
        $two = $val;
    }
    echo '<td>'.$val.'</td>';
    
}
?>

                                        <td><?php 
                                         $avg_sum = $avg_sum/3;
                                         echo $res_avg = round($avg_sum);
                                          ?></td>
                                        <?php $orders = explode(',', $products_detail['orders']); ?> 
                                        <td><?php echo $instransit = array_sum($orders) - $products_detail['receive']; ?></td>
                                        <td><?php echo $products_detail['closing']; ?></td>
                                        <td><?php echo $closing_stock = $products_detail['closing'] + $instransit; ?></td>
                                        <td><?php 
                                        $res = ($avg_sum * 2.5) - $closing_stock ; 
                                        echo round($res);
                                        ?></td>
                                        <?php 
                                            if (isset($column)) {
                                                $qty = ($avg_sum * 2.5) - $closing_stock ; 
                                                $qty = round($qty / $column);
                                                if ($qty < 1) {
                                                    $qty = 0;
                                                }
                                                for ($i=0; $i < $column; $i++) { 
                                                    echo '<td><input type="number" name="order['.$products_detail['product_code'].'][]" value="'.$qty.'"></td>';
                                                }
                                            }
                                        ?>
                                        <td><?php 
                                        $res = ($avg_sum * 2.5) - $closing_stock ; 
                                        echo round($res);
                                        ?><input type="hidden" name="qty[]" value="<?php echo round($res) ?>"></td>
                                        <?php 
                                            $total = $one - $two * 100;
                                            if ($two != 0) {
                                                $total = $total / $two;
                                            }
                                            $total = round($total);
                                        ?>
                                        <td><?php echo $total ?>%<input type="hidden" name="growth[]" value="<?php echo $total ?>"></td>
                                        <td><?php echo $products_detail['pack_carton']; ?></td>
                                        <td>
                                            <?php 
                                                if ($res_avg > $closing_stock) {
                                                    echo "HI";
                                                }
                                                else{
                                                    echo 'Low';
                                                }
                                            ?>
                                        </td>
                                                </tr>



                                            <?php } ?>


                                            </tbody>
                                        </table>

                                    </div>
                                </div>

                            </div>

                        

<input type="submit" name="" class="btn btn-primary pull-right">
</form>
                        </div>
                    </div>
                    <div style="height: 450px;"></div>
                </div> <!-- /.main content -->
            </div><!-- /#page-wrapper -->
        </div><!-- /#wrapper -->
        <!-- START CORE PLUGINS -->


<div class="modal fade" id="myModal" tabindex="-1" role="dialog">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                                <h1 class="modal-title">Modal title</h1>
                                            </div>
                                            <div class="modal-body">
                                                
<form method="post" id="restrict_file" action="<?php echo base_url() ?>product/csv_upload" enctype="multipart/form-data">
                          <input type="file" name="csv_name" id="csv_check" accept=".csv,.xlsx,.xls">
                                                

                                            </div>
                                            <div class="modal-footer">
                          <button type="submit" class="btn btn-danger csvbtn" >Submit</button>

                                                </form>
                                            </div>
                                        </div><!-- /.modal-content -->
                                    </div><!-- /.modal-dialog -->
                                </div><!-- /.modal -->
<script>  

$('.csvbtn').attr('disabled',true);
$('#csv_check').change(function() {
      if($(this).val()) {
        
        $('.csvbtn').attr('disabled',false);
      } 
    });

</script>

<script>

// $(document).on("change", ".order1", function() {
//     var sum = 0;
//     var th = $(this)
//     th.parent().parent().find(".order1").each(function(){
//     sum += +$(this).val();
//     console.log(sum);
//     th.parent().parent().find(".order_quantity").html(sum);
// });

// });

</script>
<style type="text/css">
    div#page-wrapper {
    width:  100%;
    margin:  0;
}

.sidebar {
    display:  none;
}
</style>

