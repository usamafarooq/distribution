<?php 

class Team_model extends MY_Model
{
	
}