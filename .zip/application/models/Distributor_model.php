<?php 

class Distributor_model extends MY_Model
{
	
}